#!/bin/bash

#/Library/TeX/texbin/checkcites
checkcites report.aux --unused

exit 0

